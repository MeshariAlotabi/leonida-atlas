# Leonida Atlas — مستكشف GTA VI العربي

موقع عربي تفاعلي غير رسمي لاستكشاف مناطق ليونيدا في GTA VI.

## النشر عبر GitHub Pages
1. أنشئ مستودعًا عامًا باسم `leonida-atlas`.
2. ارفع ملف `index.html` إلى جذر المستودع على الفرع `main`.
3. من Settings → Pages اختر Deploy from a branch ثم `main` و`/(root)` واضغط Save.
4. افتح `https://USERNAME.github.io/leonida-atlas/` بعد اكتمال النشر.

هذا مشروع من المعجبين وغير تابع لـ Rockstar Games. الخرائط والمواضع تقريبية وليست رسمية.
